package com.example.projetouniversidade;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;

import java.text.BreakIterator;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    //definir compomentes
    Button buttonRegistro;
    ListView listView;
    Spinner spiFiltro;
    String[] itens;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //esconder a barra de cima
        getSupportActionBar().hide();

        //referenciar componentes
        buttonRegistro = (Button) findViewById(R.id.buttonRegistro);

        listView = (ListView) findViewById(R.id.listView);
        Bundle extra = getIntent().getExtras();
        if (extra != null) {
            itens = extra.getStringArray("lista");
            adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1,itens);
        }
        listView.setAdapter(adapter);

        spiFiltro = (Spinner) findViewById(R.id.spiFiltro);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.Menu, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spiFiltro.setAdapter(adapter);
        spiFiltro.setOnItemSelectedListener(this);


        //clicar botão
        buttonRegistro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //para abrir a janela criada
                //esse getaplication vê onde estou no momento e me manda para o local da outra pagina
                //regi.class pós a pagina nova é uma classe
                Intent i = new Intent(getApplicationContext(), RegiCompra.class);
                startActivity(i);//iniciar a tela i
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String text = parent.getItemAtPosition(position).toString();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}