package com.example.projetouniversidade;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.hardware.Sensor;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.projetouniversidade.BD.BD;
import com.example.projetouniversidade.objetos.Registro;

import java.util.ArrayList;
import java.util.List;

public class RegiCompra extends AppCompatActivity {

    private final int PERMISSAO_REQUEST;

    {
        PERMISSAO_REQUEST = 2;
    }

    //definição da imagem.
    EditText Date2;
    EditText TextNumber;
    EditText editTextdesc;
    ImageView imgcam;
    ImageView imgcam2;
    Button Addcamera1;
    Button btn_camera;
    Button Addcamera2;
    Button btn_camera3;
    Button btnsave;
    String[] itens;
    SensorManager sensorManager;
    Sensor sensor;
    SensorEventListener sensorEventListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_regi_compra);

        //esconder a barra de cima
        getSupportActionBar().hide();

        //função para buscar ou verificar  a permição no manifest
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, 0);
        }

        //função de permissão para verificar o manifest:
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.READ_EXTERNAL_STORAGE)) {
            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, PERMISSAO_REQUEST);
            }
        }


        //referenciar a iamgeme o botão
        EditText simpleEditText = (EditText) findViewById(R.id.Date2);
        String strValue = simpleEditText.getText().toString();

        simpleEditText = (EditText) findViewById(R.id.TextNumber);
        strValue = simpleEditText.getText().toString();
        System.out.println(TextNumber + "€");


        simpleEditText = (EditText) findViewById(R.id.editTextdesc);
        strValue = simpleEditText.getText().toString();


        imgcam = (ImageView) findViewById(R.id.imgcam);
        Addcamera1 = (Button) findViewById(R.id.Addcamera1);
        btn_camera = (Button) findViewById(R.id.btn_camera);
        imgcam2 = (ImageView) findViewById(R.id.imgcam2);
        Addcamera2 = (Button) findViewById(R.id.Addcamera2);
        btn_camera3 = (Button) findViewById(R.id.btn_camera3);
        btnsave = (Button) findViewById(R.id.btnsave);
        itens = new  String[2]; //colocamos essa string pork no metodo putextra só pode entrar uma variavel


        sensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);
        sensor=sensorManager.getDefaultSensor(Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR);
        sensor=sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        sensor=sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);


        SensorManager sensorManager;
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        if (sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD) != null){
            // sucesso operação continua
        } else {
            // aqui é para parar caso náo funcione
        }


        //clicar no botão 0 para fotos
        btn_camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tirarfoto();
            }

            public void tirarfoto() {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE); //abrir camera para tirar foto
                startActivityForResult(intent, 1);
            }
        });

        btn_camera3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tirarfoto();
            }

            public void tirarfoto() {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE); //abrir camera para tirar foto
                startActivityForResult(intent, 2);
            }
        });


        Addcamera1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, 3);
            }
        });

        Addcamera2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, 4);
            }

        });

            //botáo de salvar
        btnsave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //para que nada em branco vá então fazemos o seguinte:
                if (Date2.getText().toString().equals("") || TextNumber.getText().toString().equals("") || editTextdesc.getText().toString().equals("")) {
                    Toast.makeText(RegiCompra.this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
                } else {   //instanciar a bd
                    //colocamos um context para localisar a pagina
                    BD bd = new BD(getApplicationContext());

                    //criação do objeto
                    Registro registro = new Registro();
                    registro.setDate2(Integer.parseInt(Date2.getText().toString()));
                    registro.setTextNumber(Integer.parseInt(TextNumber.getText().toString()));
                    registro.setEditTextdesc(editTextdesc.getText().toString());
                    bd.insereregistro(registro);
                    bd.close();
                    // Terminaram a responsabilidades do registo de compra
                    // Criar um intent para ir para MainActivity
                    // E necessário enviar informação

                    itens [0] = Date2.getText().toString();
                    itens [1] = TextNumber.getText().toString();

                    Toast.makeText(RegiCompra.this, "Inserido com sucesso", Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent (RegiCompra.this, MainActivity.class);
                    intent.putExtra("lista",itens);
                    startActivity(intent);
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case 1: // Fotografia à fatura
                if (resultCode == RESULT_OK) {
                    Bundle extras = data.getExtras();
                    Bitmap imagem = (Bitmap) extras.get("data");
                    imgcam.setImageBitmap(imagem);
                }
                break;
            case 2: // Fotografia à compra
                if (resultCode == RESULT_OK) {
                    Bundle extras = data.getExtras();
                    Bitmap imagem = (Bitmap) extras.get("data");
                    imgcam2.setImageBitmap(imagem);
                }
                break;
            case 3: // Imagem da galeria para a fatura
                if (resultCode == RESULT_OK) {
                    Uri selectedimage = data.getData();
                    String[] filepach = {MediaStore.Images.Media.DATA};
                    Cursor c = getContentResolver().query(selectedimage, filepach, null, null, null);
                    c.moveToFirst();
                    int columnIndex = c.getColumnIndex(filepach[0]);
                    String picturePath = c.getString(columnIndex);
                    c.close();
                    Bitmap imagem = (BitmapFactory.decodeFile(picturePath));
                    imgcam.setImageBitmap(imagem);
                }
                break;
            case 4: // Imagem da galeria para a compra
                if (resultCode == RESULT_OK) {
                    Uri selectedimage = data.getData();
                    String[] filepach = {MediaStore.Images.Media.DATA};
                    Cursor c = getContentResolver().query(selectedimage, filepach, null, null, null);
                    c.moveToFirst();
                    int columnIndex = c.getColumnIndex(filepach[0]);
                    String picturePath = c.getString(columnIndex);
                    c.close();
                    Bitmap imagem = (BitmapFactory.decodeFile(picturePath));
                    imgcam2.setImageBitmap(imagem);
                }
                break;
            default:
                System.out.println("PANIC!");
        }
        RegiCompra.super.onActivityResult(requestCode, resultCode, data);
    }

}



