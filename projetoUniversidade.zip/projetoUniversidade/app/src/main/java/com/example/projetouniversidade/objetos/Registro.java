package com.example.projetouniversidade.objetos;

public class Registro {
    int Date2;
    int TextNumber;
    String editTextdesc;

    public int getDate2() {
        return Date2;
    }

    public void setDate2(int date2) {
        Date2 = date2;
    }

    public int getTextNumber() {
        return TextNumber;
    }

    public void setTextNumber(int textNumber) {
        TextNumber = textNumber;
    }

    public String getEditTextdesc() {
        return editTextdesc;
    }

    public void setEditTextdesc(String editTextdesc) {
        this.editTextdesc = editTextdesc;
    }



}
