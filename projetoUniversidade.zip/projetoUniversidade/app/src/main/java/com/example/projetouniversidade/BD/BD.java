package com.example.projetouniversidade.BD;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.projetouniversidade.objetos.Registro;

import java.util.ArrayList;
import java.util.List;

//classe par criar a nossa base de dados
public class BD extends SQLiteOpenHelper {
    public BD(Context context) {
        //nome da base de dados
        super(context, " BaseRegi", null, 1);
    }

    @Override
    //metodo executado pela aplicação quando não existe nenhum outro banco
    //quando abrir a app ele cria o banco esse banco
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE registro (Date2 INTEGER, TextNumber INTEGER, editTextdesc Text)";
        db.execSQL(sql);
        db.execSQL(sql);
    }

    //no caso de atualizar a BD fica:
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String sql = "DROP TABLE IF EXISTS registro";
        db.execSQL(sql); //a atualização do banco de dados quando se tratar de uma atualização de verção
        onCreate(db);
    }

    //metodos que iremos usar
    //metodo de inserção:
    public void insereregistro(Registro registro) {
        //indicar que o metodo é gravavel tudo que for inserido é gravado
        SQLiteDatabase db = getWritableDatabase();
        //local para colocar os dados, esse dados é para indicar que elaa contem valores
        ContentValues dados = new ContentValues();

        dados.put("Date2", registro.getDate2());
        dados.put("TextNumber", registro.getEditTextdesc());
        dados.put("editTextdesc ", registro.getEditTextdesc());
        //dizer onde quero colocar os dados:
        db.insert("Registro", null, dados);
    }
    //metodo de busca da BD
    //metodo para buscar Registro em uma lista

    public List<Registro> buscaregistro() {
        //ele aqui esta dizer que quer ler os dados dentro da bd
        SQLiteDatabase db = getReadableDatabase();
        //string filtro
        String sql = "SELECT * FROM registro;";
        //rawQuery quer dizer que ele realizara uma pesquisa total na BD
        //esse null significa qiue ele não enviara argumento algum.
        Cursor c = db.rawQuery(sql, null);

        //criando a lista
        List<Registro> registros = new ArrayList<Registro>();

        //agora criaremos um ciclo a informar enquanto o cursor poder se mover ele contia a rodar
        //objeto Registro quer um novo Registro
        while (c.moveToNext()) {
            Registro registro = new Registro();
            registro.setDate2(c.getInt(c.getColumnIndex("Date2")));
            registro.setTextNumber(c.getInt(c.getColumnIndex("TextNumber")));
            registro.setEditTextdesc(c.getString(c.getColumnIndex("EditTextdesc")));

            //assim que termina de ler na BD ele faz o seguinte adicionar na tabela o objeto Registro
            registros.add(registro);
        }
        return registros;


    }
}


